firebaseio_url = "<FIREBASE_IO_URL>"
uid = "master"
firebase_credentials = "firebase-credentials.json"